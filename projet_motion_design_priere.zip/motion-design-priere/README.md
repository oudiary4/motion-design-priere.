# Comment faire une bonne prière — Motion design

Projet Remotion en français, format 16:9, 1920×1080, 30 images/seconde, durée 60 secondes.

## Contenu
- 6 séquences de 10 secondes
- Personnage stickman original en illustration vectorielle
- Textes animés et transitions douces
- Musique non incluse : ajoute uniquement une piste audio libre de droits si tu en as besoin.

## Lancer le projet
Il faut un environnement qui peut exécuter Node.js (ordinateur ou environnement cloud compatible).

```bash
npm install
npm run start
```

Pour rendre le MP4 :

```bash
npm run render
```

Le fichier final sera créé dans `output/priere.mp4`.

## Sur téléphone
L'application GitHub permet de consulter et téléverser le code, mais elle ne compile pas le projet en MP4. Il faut un environnement Node.js compatible pour lancer les commandes ci-dessus.
