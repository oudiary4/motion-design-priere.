import React from "react";
import { Composition } from "remotion";
import { PrayerVideo } from "./PrayerVideo";

export const RemotionRoot: React.FC = () => (
  <Composition
    id="Priere"
    component={PrayerVideo}
    durationInFrames={1800}
    fps={30}
    width={1920}
    height={1080}
  />
);
