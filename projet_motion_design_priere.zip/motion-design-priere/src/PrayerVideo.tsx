import React from "react";
import {
  AbsoluteFill, interpolate, useCurrentFrame, useVideoConfig,
} from "remotion";

const scenes = [
  { title: "COMMENT FAIRE", sub: "UNE BONNE PRIÈRE ?", small: "Prendre un moment pour se rapprocher d’Allah", icon: "✦" },
  { title: "1. SE PRÉPARER", sub: "Faire ses ablutions et choisir un endroit propre", small: "Se présenter à la prière avec calme et respect", icon: "☾" },
  { title: "2. AVOIR L’INTENTION", sub: "Savoir quelle prière on s’apprête à accomplir", small: "L’intention se trouve dans le cœur", icon: "♡" },
  { title: "3. SE CONCENTRER", sub: "Se tourner vers la Qibla et commencer sereinement", small: "Éloigner les distractions autant que possible", icon: "⌖" },
  { title: "4. PRENDRE SON TEMPS", sub: "Réciter et accomplir chaque geste avec tranquillité", small: "Comprendre le sens de ce que l’on récite aide à se concentrer", icon: "⋯" },
  { title: "5. TERMINER EN PAIX", sub: "Achever la prière puis faire ses invocations", small: "La régularité et la sincérité comptent", icon: "✧" },
];

const StickFigure: React.FC<{ frame: number }> = ({ frame }) => {
  const bob = Math.sin(frame / 12) * 7;
  return (
    <svg width="520" height="600" viewBox="0 0 520 600">
      <ellipse cx="260" cy="545" rx="150" ry="18" fill="#172B3A" opacity=".12" />
      <g transform={`translate(0 ${bob})`} stroke="#F4F0E8" strokeWidth="17" strokeLinecap="round" strokeLinejoin="round" fill="none">
        <circle cx="260" cy="135" r="58" fill="#F4F0E8" stroke="none" />
        <path d="M260 200 L260 390" />
        <path d="M260 245 L170 330" />
        <path d="M260 245 L350 330" />
        <path d="M260 390 L190 520" />
        <path d="M260 390 L330 520" />
      </g>
      <path d="M235 135 Q260 155 285 135" stroke="#173042" strokeWidth="7" fill="none" strokeLinecap="round" />
      <circle cx="242" cy="116" r="5" fill="#173042" />
      <circle cx="278" cy="116" r="5" fill="#173042" />
    </svg>
  );
};

export const PrayerVideo: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const sceneIndex = Math.min(5, Math.floor(frame / (10 * fps)));
  const local = frame - sceneIndex * 10 * fps;
  const scene = scenes[sceneIndex];
  const enter = interpolate(local, [0, 18], [0, 1], { extrapolateRight: "clamp" });
  const exit = interpolate(local, [270, 300], [1, 0], { extrapolateLeft: "clamp" });
  const opacity = Math.min(enter, exit);
  const slide = interpolate(enter, [0, 1], [55, 0]);

  return (
    <AbsoluteFill style={{ backgroundColor: "#102A3A", color: "#F4F0E8", fontFamily: "Arial, sans-serif", overflow: "hidden" }}>
      <AbsoluteFill style={{ opacity: .16, backgroundImage: "radial-gradient(circle at 75% 20%, #D6B56D 0 2px, transparent 3px), radial-gradient(circle at 15% 80%, #D6B56D 0 2px, transparent 3px)", backgroundSize: "90px 90px" }} />
      <div style={{ position: "absolute", top: 70, left: 90, color: "#D6B56D", fontSize: 25, letterSpacing: 8, fontWeight: 700 }}>PAUSE • FOI • SINCÉRITÉ</div>
      <div style={{ position: "absolute", left: 110, top: 260, width: 950, opacity, transform: `translateY(${slide}px)` }}>
        <div style={{ color: "#D6B56D", fontSize: 92, lineHeight: 1.05, fontWeight: 800, letterSpacing: -3 }}>{scene.title}</div>
        <div style={{ marginTop: 28, fontSize: 55, lineHeight: 1.18, fontWeight: 600 }}>{scene.sub}</div>
        <div style={{ marginTop: 35, color: "#B9C8CE", fontSize: 30, lineHeight: 1.35 }}>{scene.small}</div>
      </div>
      <div style={{ position: "absolute", right: 80, top: 220, opacity, transform: `translateY(${slide * -0.4}px)` }}>
        <StickFigure frame={frame} />
      </div>
      <div style={{ position: "absolute", right: 150, top: 115, fontSize: 80, color: "#D6B56D", opacity: .9 }}>{scene.icon}</div>
      <div style={{ position: "absolute", bottom: 75, left: 110, right: 110, height: 5, backgroundColor: "#355264", borderRadius: 8 }}>
        <div style={{ width: `${(frame / 1799) * 100}%`, height: "100%", backgroundColor: "#D6B56D", borderRadius: 8 }} />
      </div>
      <div style={{ position: "absolute", bottom: 95, right: 110, fontSize: 22, color: "#B9C8CE" }}>60 SECONDES • MOTION DESIGN</div>
    </AbsoluteFill>
  );
};
